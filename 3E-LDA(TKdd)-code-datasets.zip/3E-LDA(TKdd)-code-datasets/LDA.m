function [coeff, latent]= LDA(data, labels,no_dims)
% Make sure labels are nice
	[classes, bar, labels] = unique(labels);
    nc = length(classes);
    dataMean = mean(data, 1);
    Sb = 0;
    for i = 1:nc
         cur_X = data(labels == i,:);
         meanTemp = mean(cur_X, 1);
         
         Sb = Sb + size(cur_X,1)*(meanTemp'-dataMean')*(meanTemp'-dataMean')';
    end
    
    Sw = 0;
    for i = 1:nc
        cur_X = data(labels == i,:);
        meanTemp = mean(cur_X, 1);
        cur_N = size(cur_X,1);
        for j = 1:cur_N
            dataTemp = cur_X(j, :);
            Sw =  Sw + (meanTemp' - dataTemp')*(meanTemp' - dataTemp')';
        end
    end
    Sb(isnan(Sb)) = 0; Sw(isnan(Sw)) = 0;
	Sb(isinf(Sb)) = 0; Sw(isinf(Sw)) = 0;
    S = Sw\Sb;
    S(isinf(S)) = 0; S(isnan(S)) = 0;
    [coeff, latent] = eig(S);
    
     % Sort eigenvalues and eigenvectors in descending order
    latent(isnan(latent)) = 0;
    [latent, ind] = sort(diag(latent), 'descend');
    coeff = coeff(:,ind(1:min([no_dims size(coeff, 2)])));
    obj=trace(coeff'*S*coeff)
end
