function  chroms = GLLDA_L1(data , labels ,muDiWeiDu,mut,acr)
%GLLDA_L1
    [classes, bar, labels] = unique(labels);
    nc = length(classes); 
    [n,m] = size(data); 
    
    N = 100;
    N_chrom = m; 
    G = 300; 
    chrom = zeros(N, N_chrom);
    fitness = zeros(N, 1);
    fitness_best = zeros(1, G);
    chroms = [];
    [md,dij] = myMdDij(data, labels);
    for mw=1:muDiWeiDu
        if mw>1
            for k = 1:nc
                 cur_X = data(labels == k,:);
                 n_X = size(cur_X,1); 
                 md(:,k) = md(:,k) - coeff_v'*coeff_v*md(:,k);
                 for i = 1:n_X
                    for j = 1:n_X
                        dij(:,k,i,j) = dij(:,k,i,j) - coeff_v'*coeff_v*dij(:,k,i,j);
                    end
                 end
             end
        end
    for i =1:N +1;
        V = rand(1,N_chrom);
        chrom(i,:) =  V/norm(V);
    end
     for i =1:N +1
        fitness(i,1) = Fitness( data,labels,chrom(i,:),md,dij );
     end
    fitness_best_current = max(max(fitness)) ; 
    [x ,~]=find(fitness== fitness_best_current) ;
    chrom_best_current = chrom(x,:);     
    chrom(x,:) = chrom(N+1,:);chrom(N+1,:) = zeros(1,N_chrom); 
    fitness(x,1) = fitness(N+1,1);fitness(N+1,1) = 0;
    V = zeros(N, N_chrom);
    F = zeros(N, 1);
    for i =1:N
        V(i,:) = chrom(i,:) - chrom_best_current; 
        F(i,1) = fitness(i,1) - fitness_best_current; 
    end
    chrom_best = [];
    fitness_bestA = 0;
     Vc = zeros(N, N_chrom);
     Fc = zeros(N, 1);   
     ggg = 1;
     
for g=1:G
   Vc = crossV(V,acr);
   for i =1:N
       Vc(i,:) = mutateV(V(i,:),mut);
   end
   
   for i =1:N
       Fc(i,1) = Fitness( data,labels,Vc(i,:),md,dij );
       if Fc(i,1)>fitness_best_current 
           fitness_best_current = Fc(i,1);
           chrom_best_current = Vc(i,:);
       end
   end
   fitness_best(1,g) = fitness_best_current;
   if fitness_best(1,g) > fitness_bestA
       ggg = g
       fitness_bestA = fitness_best(1,g);
       chrom_best = chrom_best_current;
   end
   if g - ggg >= 5
       break;
   end
    F(isnan(F)) = 0; F(isinf(F)) = 0;  V(isnan(V)) = 0; V(isinf(V)) = 0;
    Fc(isnan(Fc)) = 0; Fc(isinf(Fc)) = 0; Vc(isnan(Vc)) = 0; Vc(isinf(Vc)) = 0;
    F1 = [F; Fc];
    V1 = [V;Vc];
    V2 = zeros(2*N,N_chrom); 
    [F1,ind] = sort(F1,'descend'); 
    for i=1:2*N
        V2(i,:) = V1(ind(i),:); 
    end
    V1 = V2;
    for i=1:N
        V1(i,:) = V1(2*i-1,:);
        F1(i,1) = F1(2*i-1,1); 
    end
    for i=1:N    
        V(i,:) = V1(i,:);
        F(i,1) = F1(i,1); 
    end
   for i =1:N  
       F(i,1) = Fitness( data,labels,V(i,:),md,dij );
   end
   F(isnan(F)) = 0; F(isinf(F)) = 0;
    fitness_best_current = max(max(F)) ; 
    [x ,~]=find(F== fitness_best_current) ;
    chrom_best_current = V(x,:);
   for i =1:N
        V(i,:) = V(i,:) - chrom_best_current;  
        F(i,1) = F(i,1) - fitness_best_current; 
   end
end
    coeff_v = chrom_best;
    chroms = [chroms;chrom_best];
    end 
end
    
function  [md,dij] = myMdDij(data, labels)
    [classes, bar, labels] = unique(labels);
    nc = length(classes);
    [n,m] = size(data);
     dataMean = mean(data, 1);
    for k = 1:nc
         cur_X = data(labels == k,:); 
         meanTemp = mean(cur_X, 1);  
         md(:,k) = (dataMean - meanTemp)';  
    end
    for k = 1:nc
        cur_X = data(labels == k,:); 
        n_X = size(cur_X,1); 
        for i = 1:n_X
            dataTemp_i = cur_X(i, :) - dataMean;  
            for j = 1:n_X
                dataTemp_j = cur_X(j, :) - dataMean;  
                dij(:,k,i,j) = (dataTemp_i - dataTemp_j)' ;
            end
        end
    end
end

function chrom_i = mutateV(chromi,rate)
    [~,M] = size(chromi);
    for m=1:M
        rate_mutateV = rand();
        if rate_mutateV <rate
            chromi(1,m) = (2*rand()-0.5);
        end
    end

    chrom_i = chromi(1,:);
    chrom_i = chrom_i/norm(chrom_i);
end

function  chrom = crossV(chrom,rate)
    [N,M] = size(chrom);
    for i = 1:N
        j  = floor(rand*N);
        if j==0
            j=1;
        end
        for m=1:M
            rate_crossV = rand(); 
            if rate_crossV <rate
                temp = chrom(i,m);
                chrom(i,m) = chrom(j,m);
                chrom(j,m) = temp;
            end
        end
        chrom(i,:) = chrom(i,:)/norm(chrom(i,:));
        chrom(j,:) = chrom(j,:)/norm(chrom(j,:));
    end
end

function fit = Fitness( data,labels,V,md,dij )
    [classes, bar, labels] = unique(labels);
    nc = length(classes); 
    [n,m] = size(data);
    Sb = 0;
    for k = 1:nc
         cur_X = data(labels == k,:);
         n_X = size(cur_X,1); 
         sbk =n_X *  abs(V*md(:,k)) ; 
         Sb = Sb + sbk;
    end
    Su = 0;
    BZ = 0.1; 
    for k = 1:nc
        cur_X = data(labels == k,:);
        n_X = size(cur_X,1);
        S = constructW(cur_X); 
        S = full(S);   
        W = ones(n_X,n_X)*(1/n_X); 
        for i = 1:n_X
            for j = 1:n_X
                Q(i,j) = ( BZ*S(i,j) + (1-BZ)*W(i,j) ); 
                sij = abs(V*dij(:,k,i,j)) * Q(i,j); 
                Su =  Su + sij;
            end
        end
    end
    Su = Su/2;
    fit = Sb/Su; 
end    

function D = EuDist2(fea_a,fea_b,bSqrt)
if ~exist('bSqrt','var')
    bSqrt = 1;
end

if (~exist('fea_b','var')) || isempty(fea_b)
    aa = sum(fea_a.*fea_a,2);
    ab = fea_a*fea_a';
    
    if issparse(aa)
        aa = full(aa);
    end
    
    D = bsxfun(@plus,aa,aa') - 2*ab;
    D(D<0) = 0;
    if bSqrt
        D = sqrt(D);
    end
    D = max(D,D');
else
    aa = sum(fea_a.*fea_a,2);
    bb = sum(fea_b.*fea_b,2);
    ab = fea_a*fea_b';

    if issparse(aa)
        aa = full(aa);
        bb = full(bb);
    end

    D = bsxfun(@plus,aa,bb') - 2*ab;
    D(D<0) = 0;
    if bSqrt
        D = sqrt(D);
    end
end
end


function W = constructW(fea)

      options = [];
      options.NeighborMode = 'KNN';
      options.WeightMode = 'HeatKernel';
      options.t = 1;
bSpeed  = 1;

if (~exist('options','var'))
   options = [];
end

if isfield(options,'Metric')
    warning('This function has been changed and the Metric is no longer be supported');
end


if ~isfield(options,'bNormalized')
    options.bNormalized = 0;
end

%=================================================
if ~isfield(options,'NeighborMode')
    options.NeighborMode = 'KNN';
end

switch lower(options.NeighborMode)
    case {lower('KNN')}  %For simplicity, we include the data point itself in the kNN
        if ~isfield(options,'k')
            options.k = 5;
        end
    case {lower('Supervised')}
        if ~isfield(options,'bLDA')
            options.bLDA = 0;
        end
        if options.bLDA
            options.bSelfConnected = 1;
        end
        if ~isfield(options,'k')
            options.k = 0;
        end
        if ~isfield(options,'gnd')
            error('Label(gnd) should be provided under ''Supervised'' NeighborMode!');
        end
        if ~isempty(fea) && length(options.gnd) ~= size(fea,1)
            error('gnd doesn''t match with fea!');
        end
    otherwise
        error('NeighborMode does not exist!');
end

%=================================================

if ~isfield(options,'WeightMode')
    options.WeightMode = 'HeatKernel';
end

bBinary = 0;
bCosine = 0;
switch lower(options.WeightMode)
    case {lower('Binary')}
        bBinary = 1; 
    case {lower('HeatKernel')}
        if ~isfield(options,'t')
            nSmp = size(fea,1);
            if nSmp > 3000
                D = EuDist2(fea(randsample(nSmp,3000),:));
            else
                D = EuDist2(fea);
            end
            options.t = mean(mean(D));
        end
    case {lower('Cosine')}
        bCosine = 1;
    otherwise
        error('WeightMode does not exist!');
end

%=================================================

if ~isfield(options,'bSelfConnected')
    options.bSelfConnected = 0;
end

%=================================================

if isfield(options,'gnd') 
    nSmp = length(options.gnd);
else
    nSmp = size(fea,1);
end
maxM = 62500000; %500M
BlockSize = floor(maxM/(nSmp*3));


if strcmpi(options.NeighborMode,'Supervised')
    Label = unique(options.gnd);
    nLabel = length(Label);
    if options.bLDA
        G = zeros(nSmp,nSmp);
        for idx=1:nLabel
            classIdx = options.gnd==Label(idx);
            G(classIdx,classIdx) = 1/sum(classIdx);
        end
        W = sparse(G);
        return;
    end
    
    switch lower(options.WeightMode)
        case {lower('Binary')}
            if options.k > 0
                G = zeros(nSmp*(options.k+1),3);
                idNow = 0;
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    D = EuDist2(fea(classIdx,:),[],0);
                    [dump idx] = sort(D,2); % sort each row
                    clear D dump;
                    idx = idx(:,1:options.k+1);
                    
                    nSmpClass = length(classIdx)*(options.k+1);
                    G(idNow+1:nSmpClass+idNow,1) = repmat(classIdx,[options.k+1,1]);
                    G(idNow+1:nSmpClass+idNow,2) = classIdx(idx(:));
                    G(idNow+1:nSmpClass+idNow,3) = 1;
                    idNow = idNow+nSmpClass;
                    clear idx
                end
                G = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
                G = max(G,G');
            else
                G = zeros(nSmp,nSmp);
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    G(classIdx,classIdx) = 1;
                end
            end
            
            if ~options.bSelfConnected
                for i=1:size(G,1)
                    G(i,i) = 0;
                end
            end
            
            W = sparse(G);
        case {lower('HeatKernel')}
            if options.k > 0
                G = zeros(nSmp*(options.k+1),3);
                idNow = 0;
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    D = EuDist2(fea(classIdx,:),[],0);
                    [dump idx] = sort(D,2); % sort each row
                    clear D;
                    idx = idx(:,1:options.k+1);
                    dump = dump(:,1:options.k+1);
                    dump = exp(-dump/(2*options.t^2));
                    
                    nSmpClass = length(classIdx)*(options.k+1);
                    G(idNow+1:nSmpClass+idNow,1) = repmat(classIdx,[options.k+1,1]);
                    G(idNow+1:nSmpClass+idNow,2) = classIdx(idx(:));
                    G(idNow+1:nSmpClass+idNow,3) = dump(:);
                    idNow = idNow+nSmpClass;
                    clear dump idx
                end
                G = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
            else
                G = zeros(nSmp,nSmp);
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    D = EuDist2(fea(classIdx,:),[],0);
                    D = exp(-D/(2*options.t^2));
                    G(classIdx,classIdx) = D;
                end
            end
            
            if ~options.bSelfConnected
                for i=1:size(G,1)
                    G(i,i) = 0;
                end
            end

            W = sparse(max(G,G'));
        case {lower('Cosine')}
            if ~options.bNormalized
                fea = NormalizeFea(fea);
            end

            if options.k > 0
                G = zeros(nSmp*(options.k+1),3);
                idNow = 0;
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    D = fea(classIdx,:)*fea(classIdx,:)';
                    [dump idx] = sort(-D,2); % sort each row
                    clear D;
                    idx = idx(:,1:options.k+1);
                    dump = -dump(:,1:options.k+1);
                    
                    nSmpClass = length(classIdx)*(options.k+1);
                    G(idNow+1:nSmpClass+idNow,1) = repmat(classIdx,[options.k+1,1]);
                    G(idNow+1:nSmpClass+idNow,2) = classIdx(idx(:));
                    G(idNow+1:nSmpClass+idNow,3) = dump(:);
                    idNow = idNow+nSmpClass;
                    clear dump idx
                end
                G = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
            else
                G = zeros(nSmp,nSmp);
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    G(classIdx,classIdx) = fea(classIdx,:)*fea(classIdx,:)';
                end
            end

            if ~options.bSelfConnected
                for i=1:size(G,1)
                    G(i,i) = 0;
                end
            end

            W = sparse(max(G,G'));
        otherwise
            error('WeightMode does not exist!');
    end
    return;
end


if bCosine && ~options.bNormalized
    Normfea = NormalizeFea(fea);
end

if strcmpi(options.NeighborMode,'KNN') && (options.k > 0)
    if ~(bCosine && options.bNormalized)
        G = zeros(nSmp*(options.k+1),3);
        for i = 1:ceil(nSmp/BlockSize)
            if i == ceil(nSmp/BlockSize)
                smpIdx = (i-1)*BlockSize+1:nSmp;
                dist = EuDist2(fea(smpIdx,:),fea,0);
                if bSpeed
                    nSmpNow = length(smpIdx);
                    dump = zeros(nSmpNow,options.k+1);
                    idx = dump;
                    for j = 1:options.k+1
                        [dump(:,j),idx(:,j)] = min(dist,[],2);
                        temp = (idx(:,j)-1)*nSmpNow+[1:nSmpNow]';
                        dist(temp) = 1e100;
                    end
                else
                    [dump idx] = sort(dist,2); % sort each row
                    idx = idx(:,1:options.k+1);
                    dump = dump(:,1:options.k+1);
                end
                
                if ~bBinary
                    if bCosine
                        dist = Normfea(smpIdx,:)*Normfea';
                        dist = full(dist);
                        linidx = [1:size(idx,1)]';
                        dump = dist(sub2ind(size(dist),linidx(:,ones(1,size(idx,2))),idx));
                    else
                        dump = exp(-dump/(2*options.t^2));
                    end
                end
                
                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),1) = repmat(smpIdx',[options.k+1,1]);
                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),2) = idx(:);
                if ~bBinary
                    G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),3) = dump(:);
                else
                    G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),3) = 1;
                end
            else
                smpIdx = (i-1)*BlockSize+1:i*BlockSize;
            
                dist = EuDist2(fea(smpIdx,:),fea,0);
                
                if bSpeed
                    nSmpNow = length(smpIdx);
                    dump = zeros(nSmpNow,options.k+1);
                    idx = dump;
                    for j = 1:options.k+1
                        [dump(:,j),idx(:,j)] = min(dist,[],2);
                        temp = (idx(:,j)-1)*nSmpNow+[1:nSmpNow]';
                        dist(temp) = 1e100;
                    end
                else
                    [dump idx] = sort(dist,2); % sort each row
                    idx = idx(:,1:options.k+1);
                    dump = dump(:,1:options.k+1);
                end
                
                if ~bBinary
                    if bCosine
                        dist = Normfea(smpIdx,:)*Normfea';
                        dist = full(dist);
                        linidx = [1:size(idx,1)]';
                        dump = dist(sub2ind(size(dist),linidx(:,ones(1,size(idx,2))),idx));
                    else
                        dump = exp(-dump/(2*options.t^2));
                    end
                end
                
                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),1) = repmat(smpIdx',[options.k+1,1]);
                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),2) = idx(:);
                if ~bBinary
                    G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),3) = dump(:);
                else
                    G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),3) = 1;
                end
            end
        end

        W = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
    else
        G = zeros(nSmp*(options.k+1),3);
        for i = 1:ceil(nSmp/BlockSize)
            if i == ceil(nSmp/BlockSize)
                smpIdx = (i-1)*BlockSize+1:nSmp;
                dist = fea(smpIdx,:)*fea';
                dist = full(dist);

                if bSpeed
                    nSmpNow = length(smpIdx);
                    dump = zeros(nSmpNow,options.k+1);
                    idx = dump;
                    for j = 1:options.k+1
                        [dump(:,j),idx(:,j)] = max(dist,[],2);
                        temp = (idx(:,j)-1)*nSmpNow+[1:nSmpNow]';
                        dist(temp) = 0;
                    end
                else
                    [dump idx] = sort(-dist,2); % sort each row
                    idx = idx(:,1:options.k+1);
                    dump = -dump(:,1:options.k+1);
                end

                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),1) = repmat(smpIdx',[options.k+1,1]);
                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),2) = idx(:);
                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),3) = dump(:);
            else
                smpIdx = (i-1)*BlockSize+1:i*BlockSize;
                dist = fea(smpIdx,:)*fea';
                dist = full(dist);
                
                if bSpeed
                    nSmpNow = length(smpIdx);
                    dump = zeros(nSmpNow,options.k+1);
                    idx = dump;
                    for j = 1:options.k+1
                        [dump(:,j),idx(:,j)] = max(dist,[],2);
                        temp = (idx(:,j)-1)*nSmpNow+[1:nSmpNow]';
                        dist(temp) = 0;
                    end
                else
                    [dump idx] = sort(-dist,2); % sort each row
                    idx = idx(:,1:options.k+1);
                    dump = -dump(:,1:options.k+1);
                end

                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),1) = repmat(smpIdx',[options.k+1,1]);
                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),2) = idx(:);
                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),3) = dump(:);
            end
        end

        W = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
    end
    
    if bBinary
        W(logical(W)) = 1;
    end
    
    if isfield(options,'bSemiSupervised') && options.bSemiSupervised
        tmpgnd = options.gnd(options.semiSplit);
        
        Label = unique(tmpgnd);
        nLabel = length(Label);
        G = zeros(sum(options.semiSplit),sum(options.semiSplit));
        for idx=1:nLabel
            classIdx = tmpgnd==Label(idx);
            G(classIdx,classIdx) = 1;
        end
        Wsup = sparse(G);
        if ~isfield(options,'SameCategoryWeight')
            options.SameCategoryWeight = 1;
        end
        W(options.semiSplit,options.semiSplit) = (Wsup>0)*options.SameCategoryWeight;
    end
    
    if ~options.bSelfConnected
        W = W - diag(diag(W));
    end

    if isfield(options,'bTrueKNN') && options.bTrueKNN
        
    else
        W = max(W,W');
    end
    
    return;
end


% strcmpi(options.NeighborMode,'KNN') & (options.k == 0)
% Complete Graph

switch lower(options.WeightMode)
    case {lower('Binary')}
        error('Binary weight can not be used for complete graph!');
    case {lower('HeatKernel')}
        W = EuDist2(fea,[],0);
        W = exp(-W/(2*options.t^2));
    case {lower('Cosine')}
        W = full(Normfea*Normfea');
    otherwise
        error('WeightMode does not exist!');
end

if ~options.bSelfConnected
    for i=1:size(W,1)
        W(i,i) = 0;
    end
end

W = max(W,W');
end



