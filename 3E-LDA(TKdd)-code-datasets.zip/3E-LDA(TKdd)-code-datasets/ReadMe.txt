Using Guide

E3_LDA.m : Our algorithm 3E-LDA;

LDA.m : Eigenfaces vs. fisherfaces: Recognition using class specific linear projection (Belhumeur et al., 1997)

SULDA.m : Sparse Uncorrelated Linear Discriminant Analysis (Zhang & Chu, 2013)

RILDA.m : Rotational Invariant Dimensionality Reduction Algorithms (Lai et al., 2017)

GLLDA_L1.m : A new linear discriminant analysis algorithm based on L1-norm
maximization and locality preserving projection (Zhang et al., 2018)

RLDA.m : A New Formulation of Linear Discriminant Analysis for Robust 
Dimensionality Reduction (Zhao et al., 2018)

Test_3E_LDA.m : Test files, run test methods and output nearest neighbor classification results

AllDataAddNoise.m : The way to add noise to training samples in the section 4.2

AddNoise_ORL.m : The way to add black and white blocks to training samples in the section 4.3

YaleB.mat, ORL_3232.mat, umist.mat, COIL50.mat, Isolet1.mat  datasets in the experiments, respectively