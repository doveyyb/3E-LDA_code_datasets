clear;clc;
% This is a test file.

%Example1��ORL face dataset
    %dataA = importdata('ORL_3232.mat');
    %dataA = importdata('YaleB.mat');
    %dataA = importdata('Isolet1.mat');
    dataA = importdata('COIL50.mat');
    data = dataA.fea;
%Example2��UMIST face dataset    
     %dataA = importdata('umist.mat'); 
     %data = dataA.X;data = data'; %data = data*256;
    
     labelO = dataA.gnd;data = [data,labelO];
   
%normalization
    data = Normalization(data);
%Generate training data and test data
    sam = 0.5; 
    [dataSample,dataTest] = dataST(data,sam);
    [classes, ~, ~] = unique(labelO);
%The number of classes
    nc = length(classes);
%Goal dimension of dimensionality reduction 
    no_dims = length(classes) - 1;
    [n0,m0] = size(dataSample);
    [n,m] = size(dataSample);
    label = dataSample(:,m);
    V = dataSample(:,1:m-1);

%%
[coeff] = E3_LDA(V,label,no_dims);               % 3E-LDA
Y = V*(coeff);

%% Testing and calculating accuracy of test samples
    [nT,mT] = size(dataTest);
    VT = dataTest(:,1:mT-1);
    labelT = dataTest(:,mT);
    YT = VT*(coeff);
    labelFinal = NearestN(Y,YT,label);
    labelFinal = labelFinal';
    sum = 0;
    for i=1:nT
        if( labelT(i) == labelFinal(i) )
            sum = sum+1;
        end
    end
    rate = sum/nT
%--------------------------------------------------------------------------
% Nearest neighbor classification algorithm
function labelFinal = NearestN(Y,YT,label)

% Y: Training samples after dimensionality reduction
% YT: Test samples after dimensionality reduction
% label: The labels of training samples
label = label';
[n,m] = size(Y);
[nT,mT] = size(YT);
distance = [];
for i=1:nT
    for j=1:n
         sumij = 0;
         %sumij = norm(YT(i,:)-Y(j,:),1);
         for mm=1:m
                yi = YT(i,mm);
                yj = Y(j,mm);
                sumij = sumij +  (yi - yj)^2;   % % %
         end
         distance(i,j) = sumij;
    end
    [~,index] = sort(distance(i,:),2);  
    labelFinal(i) = label( index(1,1) );
end
end
% To generate training samples and test samples
function [dataSample,dataTest] = dataST(data,sam)
% data: The samples
% sam: The rate of training samples (0,1)
% dataSample: Training samples
% dataTest: Test samples
    [n,m] = size(data);
    labels = data(:,m);
    [classes, ~, ~] = unique(labels);
    classNum = length(classes); 
    dataSample = [];
    dataTest = [];
    for i=1:classNum
        dataSample1 = [];
        dataTest1 = [];
        cur_i = data(labels == i,:);
        [ni,mi] = size(cur_i);
        nn = ni*sam; 
        idx=randperm(ni); 
        idx=idx(1:nn);     
        dataSample1 = cur_i(idx,:);
        dataTest1 = cur_i; 
        dataTest1(idx,:)=[];  
        dataSample = [dataSample;dataSample1];
        dataTest = [dataTest;dataTest1];
    end
end

% normalization  (0,1)
% The last column is the label.
function [data] = Normalization(data)
    [~,LS_m] = size(data);
    labelS = data(:,LS_m);
    data = data(:,1:LS_m-1);
    data = mapminmax(data',0, 1)';
    data(:,LS_m) = labelS;
end