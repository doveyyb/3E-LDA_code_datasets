function [bestCoeff]= RLDA(data, labels,no_dims)
%RLDA
[~,m] = size(data);
[classes, bar, labels] = unique(labels);
nc = length(classes);
man_X = 0;
for i = 1:nc
        cur_X = data(labels == i,:);  
        if size(cur_X,1)>man_X
            man_X = size(cur_X,1);
        end
end
dik = ones(nc,man_X);    
for t=1:100
    St = 0;%
    for i=1:size(data,1)
          St=St+(data(i,:))'*(data(i,:));
    end
    Sw = 0;
    for i = 1:nc
        cur_X = data(labels == i,:);
        mk = [];
        dikSum = 0;
        for j = 1:size(cur_X,1)
            dataTemp = cur_X(j, :);
            if j==1
                mk = dik(i,j) * dataTemp;
            else
                mk = mk + dik(i,j) * dataTemp;
            end
            dikSum = dikSum + dik(i,j);
        end
        mk = mk/dikSum;
        MK(i,:) = mk;
        for j = 1:size(cur_X,1)
            dataTemp = cur_X(j, :);
            Mw =  (dataTemp' - mk') *dik(i,j)* (dataTemp' - mk')' ;
            Sw =  Sw + Mw;
        end
    end
    St(isnan(St)) = 0; St(isinf(St)) = 0;
    Sw(isnan(Sw)) = 0; Sw(isinf(Sw)) = 0;
     S = St\Sw;
     [coeff, latent] = eig(S);
     % Sort eigenvalues and eigenvectors in descending order
    latent(isnan(latent)) = 0;
    [latent, ind] = sort(diag(latent), 'ascend');
    [classes, ~, ~] = unique(labels);
    coeff = coeff(:,ind(1:min([no_dims size(coeff, 2)])));
    for i = 1:nc
        cur_X = data(labels == i,:); 
         for j = 1:size(cur_X,1)
            dataTemp = cur_X(j, :);
            Dw=norm((dataTemp - MK(i,:))*coeff);
            dik(i,j)=0.5/Dw;
         end
    end
    
    A0 = coeff;
    obj(t)=trace(A0'*(S)*A0)
    
    if t>1
        if abs(obj(t)-obj(t-1))/obj(t) <0.001
             break
         end
    end

end  
     bestCoeff = coeff ;      
end
