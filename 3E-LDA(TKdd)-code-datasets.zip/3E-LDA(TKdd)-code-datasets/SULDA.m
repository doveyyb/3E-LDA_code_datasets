function [Gk] = SULDA(X, label, lambda2, stop, Q, maxSteps, tol)
%SULDA Sparse Uncorrelated Linear Discriminant Analysis

% Input checking
if nargin < 2
  error( 'Input arguments X and Y must be specified.');
end

[n , p] = size(X); % n: #observations, p: #variables
%K = no_dims+1; % K is the number of classes
[classes, ~, ~] = unique(label);
K = length(classes);%The number of classes
    Y = zeros(n,K);
    for i=1:n
        Y(i,label(i)) = 1;
    end

if nargin < 8
  verbose = false;
end
if nargin < 7
  tol = 1e-5;
end
if nargin < 6
  maxSteps = 100;
end
if nargin < 5
  Q = K - 1; % Q is the number of components
elseif Q > K - 1
  Q = K - 1;
end
if nargin < 4
  stop = ceil(p/2);
end
if nargin < 3
  lambda2 = 1e-6;
end

% check stopping criterion
if length(stop) ~= K
  stop = stop(1)*ones(1,K);
end

% Setup
% -------------------------------------------------------------------------
dataMean = mean(X, 1);
Ht = [];%
for i=1:size(X,1)
        Ht=[Ht ,(X(i,:)-dataMean)'];
end
[U,S,~] = svd(Ht,'econ');
s = diag(S);
rank_S = nnz(s)-1;
S = S(1:rank_S,1:rank_S);
U = U(:,1:rank_S);
VV = S*U';
Hb = [];
for i = 1:K
         cur_X = X(Y(:,i) == 1,:);
         cur_N = size(cur_X,1);
         meanTemp = mean(cur_X, 1);
         Hb = [Hb ,sqrt(cur_N)*(meanTemp'-dataMean') ];
end
VV2 = VV*Hb;
[P1,~,~] = svd(VV2,'econ');
P = P1(:,1:Q);
Iq = eye(Q,Q);
b = VV'*P*Iq ;
Gk = b;
% Main loop
step = 0; % iteration counter
ridgeCost = inf;
convergenceCriterion = inf;

  u = 0.2;  r = 1;
  Vk = b;Vkk = b; e = 0.9;
  while convergenceCriterion > tol && step < maxSteps
    step = step + 1;
    
    b1 = abs(Vkk)-u;
    Gk = e*(sign(Vkk).*(max(b1,0)) );
    Vk0 = Vk;
    Vk = Vk0 - r*U*(U'*Gk - inv(S)*P);=
    a = (step*2+3)/(step+3) ;
    Vkk = a*Vk + (1-a)*Vk0;
    
    ridgeCost_old = ridgeCost;
    errorC = U'*Gk - inv(S)*P;
    ridgeCost = 0;
    for i=1:rank_S
        ridgeCost = ridgeCost+ norm(errorC(i,:),2)^2 + lambda2*norm(Gk(i,:),2)^2 ;
    end
    convergenceCriterion = abs(ridgeCost_old - ridgeCost);
    con(step) = convergenceCriterion;
    if step>5 && con(step)>con(step-2)
        break;
    end
  end
end