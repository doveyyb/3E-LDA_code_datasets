function data1 = AddNoise_ORL(data,noiseNum)
%To add black and white blocks to training samples;
%In the section 4.3
%data: training samples;
%noiseNum: the number of black and white blocks in each training sampless;

% select 40% from training to add black and white blocks,[data,data2] = dataST(data,0.4);
[data,data2] = dataST(data,0.4);
[n,m] = size(data);
mm = sqrt(m-1);
for i=1:n
    P1 = data(i,:);
    PP1 = zeros(mm,mm);
    for j=1:mm
        PP1(j,:) = P1(1,(1+(j-1)*mm):(mm+(j-1)*mm));
    end
%imshow(PP1'/256);
    for kkk = 1:noiseNum 
                noiseSizeI = floor(rand()*2+3);
                noiseSizeJ = floor(rand()*2+3);
                locate_i = floor(rand()*(23-noiseSizeI));
                locate_j = floor(rand()*(28-noiseSizeJ));
                if locate_i==0 || locate_j==0
                    locate_i = locate_i+1;
                    locate_j = locate_j+1;
                end
                for i=locate_i:locate_i+noiseSizeI
                    for j=locate_j:locate_j+noiseSizeJ
                       nn = rand()*2;
                       if  ( PP1(i,j) + nn*PP1(i,j)) >= 350
                            PP1(i,j) = 155;
                       else
                           PP1(i,j) = 55;
                       end
                   end
                end
    end
%imshow(PP1'/256);
            dataChange = [];
            for j=1:mm
                dataChange =  [dataChange,PP1(j , : )];
            end
            data(i,1:m-1) = dataChange;
end
data1 = [data;data2];
end

function [dataSample,dataTest] = dataST(data,sam)
% data: The samples
% sam: The rate of training samples (0,1)
% dataSample: Training samples
% dataTest: Test samples
    [n,m] = size(data);
    labels = data(:,m);
    [classes, ~, ~] = unique(labels);
    classNum = length(classes); 
    dataSample = [];
    dataTest = [];
    for i=1:classNum
        dataSample1 = [];
        dataTest1 = [];
        cur_i = data(labels == i,:);
        [ni,mi] = size(cur_i);
        nn = ni*sam; 
        idx=randperm(ni); 
        idx=idx(1:nn);     
        dataSample1 = cur_i(idx,:);
        dataTest1 = cur_i; 
        dataTest1(idx,:)=[];  
        dataSample = [dataSample;dataSample1];
        dataTest = [dataTest;dataTest1];
    end
end