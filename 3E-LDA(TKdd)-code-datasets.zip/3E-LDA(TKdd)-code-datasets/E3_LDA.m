function [Q]= E3_LDA(X,labels,no_dims)
%3E-LDA
%An Enhanced Linear Discriminant Analysis for Robustly and Completely Preserving Local Geometrical Information
%Q:projection matrix,
%X:data matrix, each row is a data point
%labels:The labels of data
%no_dims:Goal dimension of dimensionality reduction 

[n,m] = size(X);
%The parameter to prevent cij from containing zero
epsilon = 10^(-3);
%The parameter to prevent cur_1 from containing zero
beta = ones(1,m)*epsilon;

[classes, ~, ~] = unique(labels);
% The number of classes
nc = length(classes);
           % 1. Calculation weighted median
           meanTemp = zeros(nc,m);
           cur_N =zeros(nc);
           for  k=1:nc
                 cur_X = X(labels == k,:);
                 cur_N(k) = size(cur_X,1);
                 cur_median = median(cur_X,1);
                 cur_1 = abs( (cur_X-repmat(cur_median,cur_N(k),1)) );
                 cur_1 = (cur_1+repmat(beta,cur_N(k),1));
                 cur_1 = 1./cur_1;  
                 cur_1Sum = sum(cur_1); 
                 meanTemp(k,:) = sum(cur_1.* cur_X)./cur_1Sum;
           end
           % 2. Calculation within-class scatter matrix Siw
           Xw = []; M = [];
           for k=1:nc
                cur_X = X(labels == k,:);
                curMean = meanTemp(k,:);
                cur_XMean = (cur_X-repmat(curMean,cur_N(k),1));
                % Calculation the weight matrix of the i-th class
                M1 = getWeightMatrix(cur_XMean);
                M = blkdiag(M,M1);
                Xw = [Xw ; cur_XMean];
           end
           M(isnan(M)) = 0; M(isinf(M)) = 0;
           Siw = Xw' *M*M'* Xw;
            % Remove non-digital data from Siw
           Siw(isnan(Siw)) = 0; Siw(isinf(Siw)) = 0;
           
           % The rank of within-class scatter matrix Siw
           n0 = rank(Siw);
           % This way can reduce the amount of calculation greatly.
           if m>n0
                 [U,S,V] = svd(Siw);
                 VV = U(:,min(n0,m-n0):m);
            else
                [U,S,V] = svd( Xw' * M);
                VV = U(:,1:n0)*sqrt(inv(S(1:n0,1:n0))) ;
            end
            meanTemp = meanTemp*VV;
           % 3. Calculation between-class scatter matrix Sib
           Sib = 0;
           for k = 1:nc-1
                for kk = k+1:nc
                   cij = 1/(norm(meanTemp(k,:)-meanTemp(kk,:))+epsilon);
                   Sib = Sib + cij*(cur_N(k)*cur_N(kk)/n)*(meanTemp(k,:)-meanTemp(kk,:))'*(meanTemp(k,:)-meanTemp(kk,:));
                end
           end 

           % Remove non-digital data from Sib
           Sib(isnan(Sib)) = 0; Sib(isinf(Sib)) = 0;
           
           [Q, latent] = eig(Sib);
          
           % Sort eigenvalues and eigenvectors in descending order
           latent(isnan(latent)) = 0;
           [~, ind] = sort(diag(latent), 'descend');
           Q = Q(:,ind(1:min([no_dims size(Q, 2)])));
           Q = VV*Q;
end

% To calculation the weight matrix.
function [M] = getWeightMatrix(data)

% data:The data to construct weight matrix.
% M:The weight matrix.

    [nSmp,nFea] = size(data);
     options = [];
     options.k = nSmp-1;
     options.NeighborMode = 'KNN';
    if nSmp <= (options.k) 
        options.k = nSmp-1;
    end
    Distance = EuDist2(data);
    [~,index] = sort(Distance,2);    
    neighborhood = index(:,2:(1+options.k));
    W = zeros(options.k,nSmp);
    for ii=1:nSmp
        z = data(neighborhood(ii,:),:)-repmat(data(ii,:),options.k,1); 
        C = sum(z.*z,2);         
        W(:,ii) = 1./C;  
        W(:,ii) = W(:,ii)/sum(W(:,ii));     
    end
    M = zeros(nSmp,nSmp);
    M(2:nSmp,:) = W;
    for i=1:nSmp
        if i>1
            tmp = M(i,i);
            M(i,i) = M(1,i);
            M(1,i) = tmp;
        end
    end
    M = -M;
    for i=1:size(M,1)
        M(i,i) = M(i,i) + 1;
    end
    M = M+ eye(nSmp,nSmp);
end
% To get the euDist distance of each two samples.
function [Distance] = EuDist2(data)

% data: The training samples.
% Distance: The set of distances.
    [n,m] = size(data);
    Distance = zeros(n,n);
    for i=1:n
        for j=i+1:n
              Distance(i,j) = norm(data(i,:)-data(j,:));
        end
    end
    for i=1:n
        for j=i+1:n
            Distance(j,i) = Distance(i,j);
        end
    end
end