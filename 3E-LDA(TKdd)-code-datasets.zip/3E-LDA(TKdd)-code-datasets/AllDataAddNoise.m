function data = AllDataAddNoise(data)
%To add noise to training samples;
%In the section 4.2
%data: training samples;
[n,m] = size(data);
for i=1:n
    idx=randperm(m-1); 
    % Select 5%-10% of the dimension to add slight disturbance
    rateNoi = (rand()*5+5)*0.01;
    mm = floor(m*rateNoi);
    idx=idx(1:mm);  
    tempData = data(i,:);
    for j=1:mm
        ran = rand();
        if ran>0.5
            tempData(1,idx(j)) = tempData(1,idx(j)) + 10;
        else
            tempData(1,idx(j)) = tempData(1,idx(j)) -10;
        end
    end
    data(i,:) = tempData;
end
end